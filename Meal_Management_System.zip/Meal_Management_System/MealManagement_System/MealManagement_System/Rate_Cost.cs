﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text; //for ItextSharp
using iTextSharp.text.pdf; //for ItextSharp ->> PDF
using System.IO; //for Input and Output


namespace MealManagement_System
{
    public partial class Rate_Cost : Form
    {
        public Rate_Cost()
        {
            InitializeComponent();
        }

        private void CountTotalMeal()
        {
            try
            {
                //ReWrite Later Update
                string query = "select SUM(Total) as TotalMeal from MealList";// where [Date] between '"+dtpStartingDate.Text+"' and '"+dtpToday.Text+"'";
                DataTable dt = DBConnection.GetDataTable(query);

                txtMeal.Text = dt.Rows[0]["TotalMeal"].ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void CountBazarCost()
        {
            try
            {
                string query = "select SUM(Amount) as TotalBazarCost from BazarCost";// where [Date] between '" + dtpStartingDate.Text + "' and '" + dtpToday.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);

                txtBazarCost.Text = dt.Rows[0]["TotalBazarCost"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }


        private void CountRate()
        {
            try
            {
                
                    double Meal, Bazar, Rate;
                    Meal = Convert.ToDouble(txtMeal.Text);
                    Bazar = Convert.ToDouble(txtBazarCost.Text);
                    Rate = (Bazar / Meal);
                    txtMealRate.Text = Math.Round(Rate, 1).ToString();
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void StartingDate()
        {
            
            dtpStartingDate.Text = "01/" + dtpToday.Value.Month.ToString() + "/" + dtpToday.Value.Year.ToString();
            DateTime dt = Convert.ToDateTime(dtpStartingDate.Text);
            
        }

        private void FillMemberName()
        {
            SqlConnection con = new SqlConnection("Data Source=NAZIBMAHFUZ;Initial Catalog=MealManagement_System;Integrated Security=True");
            string query = "select * from MemberList";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {

                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string name = myreader.GetString(0);
                    cmboName.Items.Add(name);
                    cmboName.Text = name;

                    MealCountByMember();
                    AddTotalPaymentByMember();
                    BalanceByMember();
                    Message();
                    CheckCurrentMonthData();
                    UpdateRateCost();
                    LoadFinalTransc();
                    HousingCost();
                    Message();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MealCountByMember()
        {
            
            try
            {
                string query = "select SUM(Total) as TotalMeal from MealList "
                    +"where Name='"+cmboName.Text+"' ";//and  [Date] between '"+dtpStartingDate.Text+"' and '"+dtpToday.Text+"'";

                DataTable dt = DBConnection.GetDataTable(query);
                if(dt.Rows.Count==1)
                {
                    txtTotalMeal.Text = dt.Rows[0]["TotalMeal"].ToString();
                }
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void AddTotalPaymentByMember()
        {
            string query = "select sum(Add_Amount) as TotalAdd from Payment where "
                +"Name='"+cmboName.Text+"' ";// and [Date] between '"+dtpStartingDate.Text+"' and '"+dtpToday.Text+"'";
            DataTable dt = DBConnection.GetDataTable(query);
            if (dt.Rows.Count == 1)
            {
                txtTotalAdd.Text = dt.Rows[0]["TotalAdd"].ToString();
            }
            else
            {
                double v=0.0;
                txtTotalAdd.Text = v.ToString();
            }
            
        }

        private void BalanceByMember()
        {
            
                try
                {
                    double add, cost, balance;
                    add = Convert.ToDouble(txtTotalAdd.Text);
                    cost = Convert.ToDouble(txtTotalCost.Text);
                    balance = add - cost;
                    txtBalance.Text = balance.ToString();
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }
          
        }

        private void Message()
        {
            //if (txtBalance.Text != "")
            //{
                try
                {
                    double rate, Balance;
                    rate = Convert.ToDouble(txtMealRate.Text);
                    Balance = Convert.ToDouble(txtBalance.Text);
                    if (Balance < rate)
                    {
                        txtMessage.Text = "Balance is Over Low.";
                        txtStatus.Text = "Meal Closed";
                    }
                    else if (Balance == rate)
                    {
                        txtMessage.Text = "Your Balance is Equal";
                        txtStatus.Text = "Meal Open";
                    }
                    else if (Balance <= 100)
                    {
                        txtMessage.Text = "Balance is Too Low.";
                        txtStatus.Text = "Meal Open";
                    }
                    else if (Balance > 101)
                    {
                        txtMessage.Text = "Balance is Enough";
                        txtStatus.Text = "Meal Open";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            //}
            
        }

      
        private void UpdateRateCost()
        {
            try
            {
                string query = "update Rate_Cost set Total_Meal=" + txtTotalMeal.Text + ",Cost=" + txtTotalCost.Text + ","
                + "Adding_Tk=" + txtTotalAdd.Text + ",Balance=" + txtBalance.Text + ",[Message]='" + txtMessage.Text + "',[Status]='" + txtStatus.Text + "' where Name='" + cmboName.Text + "'";
                DBConnection.ExecuteQuery(query);
                //MessageBox.Show("Successfully Update chk", "chk", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                //MessageBox.Show("Update Rate Cost Error","error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }

        private void LoadFinalTransc()
        {
            try
            {
                string query = "select * from Rate_Cost";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvFinalTransction.DataSource = dt;
                dgvFinalTransction.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        //Indivisual Cost
        private void HousingCost()
        {
            try
            {
                string query = "select SUM(HousingFee) as HF from MonthlyFee where Name='"+cmboName.Text+"'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtHousing.Text = dt.Rows[0]["HF"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GasWater()
        {
            try
            {
                string query = "select SUM(GasWater) as GW from MonthlyFee where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtGasWater.Text = dt.Rows[0]["GW"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Internet()
        {
            try
            {
                string query = "select SUM(InternetBill) as Internet from MonthlyFee where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtInternet.Text = dt.Rows[0]["Internet"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Current()
        {
            try
            {
                string query = "select SUM(CurrentBill) as CB from MonthlyFee where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtCurrent.Text = dt.Rows[0]["CB"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Bowa()
        {
            try
            {
                string query = "select SUM(BowaBill) as BB from MonthlyFee where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtBowa.Text = dt.Rows[0]["BB"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Others()
        {
            try
            {
                string query = "select SUM(OthersCost) as OC from MonthlyFee where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    txtOthers.Text = dt.Rows[0]["OC"].ToString();
                }
                else
                    MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //PersonalInfoData

        private void PersonalInfoLoad()
        {
            try
            {
                string query = "select * from MemberList where Member_Name='"+cmboName.Text+"'";
                DataTable dt = DBConnection.GetDataTable(query);
                if(dt.Rows.Count==1)
                {
                    txtPhone.Text = dt.Rows[0]["ContactNo"].ToString();
                    txtInstitution.Text = dt.Rows[0]["Institution"].ToString();
                    txtmail.Text = dt.Rows[0]["Email"].ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void NewMemberCostFillUp()
        {
            if(txtHousing.Text=="" || txtGasWater.Text=="" || txtInternet.Text=="" || txtCurrent.Text=="" || txtBowa.Text=="" || txtOthers.Text=="")
            {
                txtHousing.Text = txtGasWater.Text = txtInternet.Text = txtCurrent.Text = txtBowa.Text = txtOthers.Text = "0";
            }
        }

        private void TotalCostCurrentMonth()
        {
            try
            {
                string query = "SELECT SUM(Amount) as T from BazarCost ";//where [Date] between '"+dtpStartingDate.Text+"' and '"+dtpToday.Text+"'";
                DataTable dt = DBConnection.GetDataTable(query);
                txtCost.Text = dt.Rows[0]["T"].ToString();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TotalAdding()
        {
            try
            {
                string query = "select SUM(Add_Amount) as add_Amt from Payment ";//where [Date] between '"+dtpStartingDate.Text+"' and '"+dtpToday.Text+"'";
                DataTable dt = DBConnection.GetDataTable(query);
                txtAdd.Text = dt.Rows[0]["add_Amt"].ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Rate_Cost_Load(object sender, EventArgs e)
        {

            CountTotalMeal();
            CountBazarCost();
            CountRate();
            StartingDate();
            FillMemberName();
            CheckCurrentMonthData();
            HousingCost();
            UpdateRateCost();
            LoadFinalTransc();
            TotalCostCurrentMonth();
            TotalAdding();
            MessBalance();
        }

        private void dtpStartingDate_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void dtpToday_ValueChanged(object sender, EventArgs e)
        {
            StartingDate();
        }

        private void lblStartingDate_Click(object sender, EventArgs e)
        {

        }

        private void cmboName_SelectedIndexChanged(object sender, EventArgs e)
        {
            MealCountByMember();
            AddTotalPaymentByMember();
            BalanceByMember();
        }

        private void txtMealRate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTotalMeal_TextChanged(object sender, EventArgs e)
        {
            double meal, rate, cost;
            meal = Convert.ToDouble(txtTotalMeal.Text);
            rate = Convert.ToDouble(txtMealRate.Text);
            cost = rate * meal;
            txtTotalCost.Text = Math.Round(cost, 2).ToString();
        }

        private void checkAdd()
        {
            if(txtTotalAdd.Text=="")
            {
                double add=0;
                txtTotalAdd.Text = add.ToString();
            }
        }

        private void txtTotalAdd_TextChanged(object sender, EventArgs e)
        {
            checkAdd();
        }

        private void txtBalance_TextChanged(object sender, EventArgs e)
        {
            Message();
        }

        //private void txtBazarCost_TextChanged(object sender, EventArgs e)
        //{

        //}

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {
            if(txtMessage.Text=="Balance is Over Low")
            {
                txtMessage.BackColor = Color.Red;
            }
            else if(txtMessage.Text=="Balance is Too Low.")
            {
                txtMessage.BackColor = Color.OrangeRed;
            }
            else if (txtMessage.Text == "Balance is Enough")
                txtMessage.BackColor = Color.Green;

        }

        private void cmboName_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            
            MealCountByMember();
            AddTotalPaymentByMember();
            CheckCurrentMonthData();
            BalanceByMember();
            Message();
            UpdateRateCost();
            LoadFinalTransc();
            HousingCost();
            GasWater();
            Internet();
            Current();
            Bowa();
            Others();
            PersonalInfoLoad();
            NewMemberCostFillUp();
            IntotalCost();
            
            
        }

        private void txtTotalMeal_TextChanged_1(object sender, EventArgs e)
        {
            if(txtTotalMeal.Text!="")
            {
                try
                {
                    double meal, rate, cost;
                    meal = Convert.ToDouble(txtTotalMeal.Text);
                    rate = Convert.ToDouble(txtMealRate.Text);
                    cost = rate * meal;
                    txtTotalCost.Text = Math.Round(cost, 0).ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
            
        }

        private void txtMessage_TextChanged_1(object sender, EventArgs e)
        {
            //Message();
        }

        private void txtBalance_TextChanged_1(object sender, EventArgs e)
        {
            Message();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //InsertTblRateCost();
            //LoadFinalTransc();
        }

        private void IntotalCost()
        {
            double housing, gaswater, internet, current, bowa, others,Total;
            housing = Convert.ToDouble(txtHousing.Text);
            gaswater = Convert.ToDouble(txtGasWater.Text);
            internet = Convert.ToDouble(txtInternet.Text);
            current = Convert.ToDouble(txtCurrent.Text);
            bowa = Convert.ToDouble(txtBowa.Text);
            others = Convert.ToDouble(txtOthers.Text);

            Total = housing + gaswater + internet + current + bowa + others;
            txtInTotal.Text = Total.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtpStartingDate_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void CheckCurrentMonthData()
        {
            if (txtTotalMeal.Text == "")
                txtTotalMeal.Text = "0";
            else if (txtTotalCost.Text == "")
                txtTotalCost.Text = "0";
            else if (txtTotalAdd.Text == "")
                txtTotalAdd.Text = "0";
            else if (txtBalance.Text == "")
                txtBalance.Text = "0";
        }

        private void txtTotalAdd_TextChanged_1(object sender, EventArgs e)
        {
            BalanceByMember();
        }

        

        private void MessBalance()
        {
            if(txtCost.Text!="")
            {
                double add, cost, balance;
                add = Convert.ToDouble(txtAdd.Text);
                cost = Convert.ToDouble(txtCost.Text);
                balance = add - cost;
                txtBlnc.Text = balance.ToString();
            }
        }

        private void txtCost_TextChanged(object sender, EventArgs e)
        {
            //MessBalance();
        }

        public void exportPdf(DataGridView dgv, string filename)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.EMBEDDED);
            PdfPTable pdftable = new PdfPTable(dgv.Columns.Count);
            pdftable.DefaultCell.Padding = 3;
            pdftable.WidthPercentage = 100;
            pdftable.HorizontalAlignment = Element.ALIGN_CENTER;
            pdftable.DefaultCell.BorderWidth = 1;

            iTextSharp.text.Font text = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);
            //adding header

            foreach (DataGridViewColumn column in dgv.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, text));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdftable.AddCell(cell);
            }

            //add data row

            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    pdftable.AddCell(new Phrase(cell.Value.ToString(), text));
                }
            }

            var savefiledialoge = new SaveFileDialog();
            savefiledialoge.FileName = filename;
            savefiledialoge.DefaultExt = ".pdf";
            if (savefiledialoge.ShowDialog() == DialogResult.OK)
            {
                using (FileStream stream = new FileStream(savefiledialoge.FileName, FileMode.Create))
                {
                    Document pdfdoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                    PdfWriter.GetInstance(pdfdoc, stream);
                    pdfdoc.Open();
                    pdfdoc.Add(pdftable);
                    pdfdoc.Close();
                    stream.Close();
                }
            }
        }

        private void bunifuThinButton21_Click_1(object sender, EventArgs e)
        {
            exportPdf(dgvFinalTransction, "Meal Rate & Cost");
        }
    }
}
