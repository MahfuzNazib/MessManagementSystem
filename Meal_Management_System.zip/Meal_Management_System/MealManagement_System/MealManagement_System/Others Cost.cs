﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text; //for ItextSharp
using iTextSharp.text.pdf; //for ItextSharp ->> PDF
using System.IO; //for Input and Output

namespace MealManagement_System
{
    public partial class Others_Cost : Form
    {
        public Others_Cost()
        {
            InitializeComponent();
        }

        private void FillMemberName()
        {
            SqlConnection con = new SqlConnection("Data Source=NAZIBMAHFUZ;Initial Catalog=MealManagement_System;Integrated Security=True");
            string query = "select * from MemberList";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {

                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string name = myreader.GetString(0);
                    cmboName.Items.Add(name);
                    cmboNameAd.Items.Add(name);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
        private void button6_Click(object sender, EventArgs e)
        {
            
            
        }

        private void LoadMonthlyPaymentList()
        {
            try
            {
                string query = "select Name, [Date],(HousingFee+GasWater+InternetBill+CurrentBill+BowaBill+OthersCost) as TotalFee from MonthlyFee";
                    //+" where [Date] between '" + dtpStartingDate.Text + "' and '" + dtpDate.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);

                dgvMonthlyInfo.DataSource = dt;
                dgvMonthlyInfo.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void LoadAdvancePayment()
        {
            
            try
            {
                string query = "select * from AdvancedPayment";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvAdvanceInfo.DataSource = dt;
                dgvAdvanceInfo.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        

        private void LoadTotalCostIndivisual()
        {
            try
            {
                string query = "select Name,sum(HousingFee) as HousingCost,sum(GasWater) as GasWater_Cost,sum(InternetBill) as InternetCost,"
                    +"sum(CurrentBill) as CurrentCost,sum(BowaBill) as BowaCost,sum(OthersCost) as Otherscost from MonthlyFee group by Name "
                    +"order by HousingCost desc";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvTotalCostInfo.DataSource = dt;
                dgvTotalCostInfo.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void LoadCurrentMonthFee()
        //{
        //    try
        //    {
        //        string query = "select * from MonthlyFee where [Date] between '"+dtpDate.Text+"' and '"+dtpStartingDate.Text+"'";
        //        DataTable dt = DBConnection.GetDataTable(query);
        //        dgvMonthlyInfo.DataSource = dt;
        //        dgvMonthlyInfo.Refresh();
        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        private void Others_Cost_Load(object sender, EventArgs e)
        {
            FillMemberName();
            LoadMonthlyPaymentList();
            LoadAdvancePayment();
            LoadTotalCostIndivisual();
            setStartingDate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void setStartingDate()
        {
            dtpStartingDate.Text = dtpDate.Value.Year.ToString() + "-" + dtpDate.Value.Month.ToString() + "-" + "01";
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            setStartingDate();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            try
            {
                string query = "Insert into MonthlyFee([Date],Name,HousingFee,GasWater,InternetBill,CurrentBill,BowaBill,OthersCost) "
                + "values('" + dtpDate.Text + "','" + cmboName.Text + "'," + txtHousingFee.Text + ","
                + "" + txtGasWater.Text + "," + txtInternet.Text + "," + txtCurrent.Text + "," + txtBowa.Text + "," + txtOthers.Text + ")";

                if (cmboName.Text == "")
                {
                    MessageBox.Show("Please Fillup Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DBConnection.ExecuteQuery(query);
                MessageBox.Show(cmboName.Text + " Monthly Fee Received Successfully Done", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMonthlyPaymentList();
                LoadTotalCostIndivisual();
                cmboName.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void dgvMonthlyInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>=0)
            {
                string id = dgvMonthlyInfo.Rows[e.RowIndex].Cells[0].Value.ToString();
                try
                {
                    string query = "select * from MonthlyFee where Name='" + id + "' and [Date]='" + dtpDate.Text + "'";
                    DataTable dt = DBConnection.GetDataTable(query);
                    if(dt.Rows.Count==1)
                    {
                        cmboName.Text = dt.Rows[0]["Name"].ToString();
                        txtHousingFee.Text = dt.Rows[0]["HousingFee"].ToString();
                        txtGasWater.Text = dt.Rows[0]["GasWater"].ToString();
                        txtInternet.Text = dt.Rows[0]["InternetBill"].ToString();
                        txtCurrent.Text = dt.Rows[0]["CurrentBill"].ToString();
                        txtBowa.Text = dt.Rows[0]["BowaBill"].ToString();
                        txtOthers.Text = dt.Rows[0]["OthersCost"].ToString();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "update MonthlyFee set HousingFee="+txtHousingFee.Text+",GasWater="+txtGasWater.Text+",InternetBill="+txtInternet.Text+","
                    +"CurrentBill="+txtCurrent.Text+",BowaBill="+txtBowa.Text+",OthersCost="+txtOthers.Text+" "
                    +"where Name='"+cmboName.Text+"' and [Date]='"+dtpDate.Text+"'";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show("Successfully Update", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMonthlyPaymentList();
                LoadTotalCostIndivisual();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "delete from MonthlyFee where Name='"+cmboName.Text+"' and [Date]='"+dtpDate.Text+"'";
                if(MessageBox.Show("Are You Sure To Delete This Data?","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    DBConnection.ExecuteQuery(query);
                    MessageBox.Show("Successfully Deleted", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMonthlyPaymentList();
                    LoadTotalCostIndivisual();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string query = "insert into AdvancedPayment([Date],Name,Amount) "
                    + "values ('" + dtpDate.Text + "','" + cmboNameAd.Text + "'," + txtAmount.Text + ")";
                if (cmboNameAd.Text == "")
                {
                    MessageBox.Show("Please Fillup Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DBConnection.ExecuteQuery(query);
                MessageBox.Show(cmboName.Text + " " + txtAmount.Text + " Advanced Received", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAdvancePayment();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvAdvanceInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>=0)
            {
                string id = dgvAdvanceInfo.Rows[e.RowIndex].Cells[1].Value.ToString();
                try
                {
                    string query = "SELECT * from AdvancedPayment where Name='"+id+"'";
                    DataTable dt = DBConnection.GetDataTable(query);
                    if(dt.Rows.Count==1)
                    {
                        cmboNameAd.Text = dt.Rows[0]["Name"].ToString();
                        txtAmount.Text = dt.Rows[0]["Amount"].ToString();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "update AdvancedPayment set Amount="+txtAmount.Text+" where Name='"+cmboNameAd.Text+"'";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show("Successfully Updated", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAdvancePayment();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "DELETE from AdvancedPayment where Name='"+cmboNameAd.Text+"'";
                if (MessageBox.Show("Are You Sure To Delete This Data?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    DBConnection.ExecuteQuery(query);
                    MessageBox.Show("Successfully Deleted", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAdvancePayment();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void exportPdf(DataGridView dgv, string filename)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.EMBEDDED);
            PdfPTable pdftable = new PdfPTable(dgv.Columns.Count);
            pdftable.DefaultCell.Padding = 3;
            pdftable.WidthPercentage = 100;
            pdftable.HorizontalAlignment = Element.ALIGN_CENTER;
            pdftable.DefaultCell.BorderWidth = 1;

            iTextSharp.text.Font text = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);
            //adding header

            foreach (DataGridViewColumn column in dgv.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, text));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdftable.AddCell(cell);
            }

            //add data row

            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    pdftable.AddCell(new Phrase(cell.Value.ToString(), text));
                }
            }

            var savefiledialoge = new SaveFileDialog();
            savefiledialoge.FileName = filename;
            savefiledialoge.DefaultExt = ".pdf";
            if (savefiledialoge.ShowDialog() == DialogResult.OK)
            {
                using (FileStream stream = new FileStream(savefiledialoge.FileName, FileMode.Create))
                {
                    Document pdfdoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                    PdfWriter.GetInstance(pdfdoc, stream);
                    pdfdoc.Open();
                    pdfdoc.Add(pdftable);
                    pdfdoc.Close();
                    stream.Close();
                }
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            exportPdf(dgvTotalCostInfo, "TotalCost");
        }

        private void MonthlyFee()
        {
            try
            {
                string query = "select *  from MonthlyFee";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvMonthlyInfo.DataSource = dt;
                dgvMonthlyInfo.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Backup()
        {
            if (dgvMonthlyInfo.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);
                for (int i = 1; i < dgvMonthlyInfo.Columns.Count + 1; i++)
                {
                    xcelApp.Cells[1, i] = dgvMonthlyInfo.Columns[i - 1].HeaderText;
                }
                for (int i = 0; i < dgvMonthlyInfo.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvMonthlyInfo.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dgvMonthlyInfo.Rows[i].Cells[j].Value.ToString();
                        //xcelApp.Cells[i + 2, j + 1] = bkMealList.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MonthlyFee();
            Backup();
        }

       
    }
}
