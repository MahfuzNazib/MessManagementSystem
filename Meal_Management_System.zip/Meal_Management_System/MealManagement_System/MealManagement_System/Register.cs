﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MealManagement_System
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "insert into Login_Info(Username,[Password],Email,Name) "
                    +"values ('"+txtUsername.Text+"','"+txtPassword.Text+"','"+txtMail.Text+"','"+txtName.Text+"')";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show("New Admin Add Successfully Done", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();
            l.Show();
            this.Hide();
        }
    }
}
