﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text; //for ItextSharp
using iTextSharp.text.pdf; //for ItextSharp ->> PDF
using System.IO; //for Input and Output

namespace MealManagement_System
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        

        private void submit()
        {
            if (cmboName.Text == "")
            {
                MessageBox.Show("Name Mustbe Filled(*)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string query = "insert into Payment([Date],Name,Add_Amount) "
                + "values('" + dtpDate.Text + "','" + cmboName.Text + "'," + txtAddAmount.Text + ")";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show(cmboName.Text + " " + txtAddAmount.Text + " Taka added successfully Done", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadPaymentList();
                //UpdateBalanceTbl();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            
        }

        private void FillMemberName()
        {
            SqlConnection con = new SqlConnection("Data Source=NAZIBMAHFUZ;Initial Catalog=MealManagement_System;Integrated Security=True");
            string query = "select * from MemberList";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {

                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string name = myreader.GetString(0);
                    cmboName.Items.Add(name);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadPaymentList()
        {
            string query = "select * from Payment ";//where [Date] between '"+dtpStartingDate.Text+"' and '"+dtpDate.Text+"' ";
            DataTable dt = DBConnection.GetDataTable(query);
            dgvPayment.DataSource = dt;
            dgvPayment.Refresh();
        }

        private void LoadTotalAmountByMember()
        {
            if(cmboName.Text!="")
            {
                string query = "select Total_Amount from Balance where Name='" + cmboName.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);

                if(dt.Rows.Count==1)
                {
                    //txtTotalAmount.Text = dt.Rows[0]["Total_Amount"].ToString();
                }

            }
        }

        private void LoadTotalBalnce()
        {
            try
            {
                //string query = "select Name,SUM(Add_Amount) as TotalAmount from Payment";// where [Date] between '"+dtpStartingDate.Text+"' and '"+dtpDate.Text+"' group by Name";
                string query = "select Name,SUM(Add_Amount) from Payment group by Name";
                DataTable dt = DBConnection.GetDataTable(query);

                dgvTotalBalance.DataSource = dt;
                dgvTotalBalance.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void MonthlyTotalBalance()
        {
            try
            {
                //string query = "select SUM(Add_Amount) as TotalAmount from Payment ";//where [Date] between '" + dtpStartingDate.Value.ToShortDateString() +"' and '" + dtpDate.Value.ToShortDateString() + "'";
                string query = "select * from Payment";
                DataTable dt = DBConnection.GetDataTable(query);
                if(dt.Rows.Count==1)
                {
                    txtTotalBalance.Text = dt.Rows[0]["TotalAmount"].ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            LoadPaymentList();
            FillMemberName();
            LoadTotalBalnce();
            MonthlyTotalBalance();
        }

        private void dgvMealList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnDelete.Visible = true;
            btnUpdate.Visible = true;
            btnSave.Visible = false;

            string id = dgvPayment.Rows[e.RowIndex].Cells[1].Value.ToString();
            try
            {
                string query = "select Add_Amount from Payment where Name='" + id + "' and [Date]='" + dtpDate.Text + "'";
                DataTable dt = DBConnection.GetDataTable(query);
                if (dt.Rows.Count == 1)
                {
                    cmboName.Text = dt.Rows[0]["Name"].ToString();
                    txtAddAmount.Text = dt.Rows[0]["Add_Amount"].ToString();
                }
                else
                    MessageBox.Show("You can Update only " + dtpDate.Text + " Add Amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmboName_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadTotalAmountByMember();
        }

       
        private void txtAddAmount_TextChanged(object sender, EventArgs e)
        {
            //CalculateTotalAmount();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            submit();
        }


        private void setStartingDate()
        {
            dtpStartingDate.Text = dtpDate.Value.Year.ToString() + "-" + dtpDate.Value.Month.ToString() + "-" + "01";
        }
        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            //setStartingDate();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "update Payment set Add_Amount="+txtAddAmount.Text+" where Name='"+cmboName.Text+"' and [Date]='"+dtpDate.Text+"'";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show("Successfully Updated", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "delete from Payment where Name='"+cmboName.Text+"' and [Date]='"+dtpDate.Text+"'";
                if(MessageBox.Show("Are you sure to Delete this Data?","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    DBConnection.ExecuteQuery(query);
                    MessageBox.Show("Successfully Deleted", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dtpToDate_ValueChanged(object sender, EventArgs e)
        {
            setStartingDate();
        }


        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "select * from Payment where [Date] between '"+dtpFromDate.Text+"' and '"+dtpToDate.Text+"' ";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvPayment.DataSource = dt;
                dgvPayment.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            submit();
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            try
            {
                string query = "delete from Payment where SlNo="+lblSlNo.Text+" and Name='"+cmboName.Text+"'";
                if(MessageBox.Show("Are you Sure To Delete this Data?","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    DBConnection.ExecuteQuery(query);
                    MessageBox.Show("Successfully Deleted", "DELETED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadPaymentList();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvPayment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>=0)
            {
                string id = dgvPayment.Rows[e.RowIndex].Cells[0].Value.ToString();
                try
                {
                    string query = "select * from Payment where SlNo="+id;
                    DataTable dt = DBConnection.GetDataTable(query);
                    if(dt.Rows.Count==1)
                    {
                        lblSlNo.Text = dt.Rows[0]["SlNo"].ToString();
                        dtpDate.Text = dt.Rows[0]["Date"].ToString();
                        cmboName.Text = dt.Rows[0]["Name"].ToString();
                        txtAddAmount.Text = dt.Rows[0]["Add_Amount"].ToString();
                        
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click_2(object sender, EventArgs e)
        {
            try
            {
                string query = "Update Payment set Add_Amount="+txtAddAmount.Text+" where SlNo="+lblSlNo.Text+" and Name='"+cmboName.Text+"'";
                DBConnection.ExecuteQuery(query);
                MessageBox.Show("Successfully Update", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadPaymentList();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtSerach_OnTextChange(object sender, EventArgs e)
        {
            try
            {
                string query = "select  * from Payment where Name ='"+txtSerach.text+"'";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvPayment.DataSource = dt;
                dgvPayment.Refresh();
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            LoadPaymentList();
        }

        public void exportPdf(DataGridView dgv, string filename)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.EMBEDDED);
            PdfPTable pdftable = new PdfPTable(dgv.Columns.Count);
            pdftable.DefaultCell.Padding = 3;
            pdftable.WidthPercentage = 100;
            pdftable.HorizontalAlignment = Element.ALIGN_CENTER;
            pdftable.DefaultCell.BorderWidth = 1;

            iTextSharp.text.Font text = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);
            //adding header

            foreach (DataGridViewColumn column in dgv.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, text));
                cell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdftable.AddCell(cell);
            }

            //add data row

            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    pdftable.AddCell(new Phrase(cell.Value.ToString(), text));
                }
            }

            var savefiledialoge = new SaveFileDialog();
            savefiledialoge.FileName = filename;
            savefiledialoge.DefaultExt = ".pdf";
            if (savefiledialoge.ShowDialog() == DialogResult.OK)
            {
                using (FileStream stream = new FileStream(savefiledialoge.FileName, FileMode.Create))
                {
                    Document pdfdoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                    PdfWriter.GetInstance(pdfdoc, stream);
                    pdfdoc.Open();
                    pdfdoc.Add(pdftable);
                    pdfdoc.Close();
                    stream.Close();
                }
            }
        }

        private void bunifuThinButton21_Click_1(object sender, EventArgs e)
        {
            exportPdf(dgvPayment, "Payment_List");
        }

        private void LPayment()
        {
            try
            {
                string query = "select *  from Payment";
                DataTable dt = DBConnection.GetDataTable(query);
                dgvPayment.DataSource = dt;
                dgvPayment.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Backup()
        {
            if (dgvPayment.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);
                for (int i = 1; i < dgvPayment.Columns.Count + 1; i++)
                {
                    xcelApp.Cells[1, i] = dgvPayment.Columns[i - 1].HeaderText;
                }
                for (int i = 0; i < dgvPayment.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvPayment.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dgvPayment.Rows[i].Cells[j].Value.ToString();
                        //xcelApp.Cells[i + 2, j + 1] = bkMealList.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LPayment();
            Backup();
        }


    }
}
